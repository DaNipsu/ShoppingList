package com.example.user.shoppinglist;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;

public class Instructions extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instructions);

        WebView helpWebView;

        helpWebView = findViewById(R.id.webview01);

        helpWebView.loadUrl("file:///android_asset/instructions.html");


        Button buttonOk;
        buttonOk = (Button)findViewById(R.id.buttonOk);
        buttonOk.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent goBack = new Intent(Instructions.this, ShoppingList.class);

                startActivity(goBack);
            }
        });
    }


}
