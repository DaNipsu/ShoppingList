package com.example.user.shoppinglist;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.StringTokenizer;

public class ShoppingList extends AppCompatActivity {

    ListView shoppingList;

    public static ArrayList<String> shoppings = new ArrayList<String>();
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_list);

        shoppingList = (ListView)findViewById(R.id.list);

        //shoppings.add("item1");
       //shoppings.add("item2");

        if(shoppings != null && shoppings.size() >0) {
            adapter = new ArrayAdapter<String>(this,
                    android.R.layout.simple_list_item_1,
                    shoppings.toArray(new String[1]));
            shoppingList.setAdapter(adapter);


        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.mnAdd:
                Intent intent = new Intent(this, NewShoppingItem.class);
                startActivityForResult(intent,1);
                return true;
            case R.id.instructions:
                intent = new Intent(this, Instructions.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == 1) {
            if(resultCode == Activity.RESULT_OK){
                String result=data.getStringExtra("result");
                shoppings.add(result);

                adapter.notifyDataSetChanged();

            }

        }

    }

    // METODI, JOKA LUKEE SHAREDPREFERENCESTÄ ELI TIEDOSTOSTA
    private void lataaSharedPreferences() {
        SharedPreferences omaSharedPreferences = getPreferences(Context.MODE_PRIVATE);
        String ostoksetString = omaSharedPreferences.getString("ostokset", "");
        StringTokenizer tokenizer = new StringTokenizer(ostoksetString, "|");
        while(tokenizer.hasMoreTokens()) {
            shoppings.add(tokenizer.nextToken());
        }
    }

    // METODI, JOKA TALLENTAA SHAREDPREFENCEEN ELI TIEDOSTOSTA
    private void tallennaSharedPreferences() {
        SharedPreferences omaSharedPreferences = getPreferences(Context.MODE_PRIVATE);
        String ostoksetString = "";
        for(int i = 0; i < shoppings.size(); i++) {
            ostoksetString += shoppings.get(i) + "|";
        }
        SharedPreferences.Editor editor = omaSharedPreferences.edit();
        editor.putString("ostokset", ostoksetString);
        editor.commit();
    }

    // ELINKAARIMETODI ONPAUSE TOTEUTETAAN, JOSSA TALLENNETAAN OSTOKSET
    @Override
    protected void onDestroy() {
        super.onDestroy();
        tallennaSharedPreferences();
    }


}
